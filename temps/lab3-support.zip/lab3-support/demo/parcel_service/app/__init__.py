"""Parcel Service FastAPI application."""
