"""Locker Service FastAPI application."""
